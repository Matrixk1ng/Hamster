"""Fetch model weights once so the demo runs offline afterwards:
MediaPipe BlazeFace + Hand Landmarker + Face Landmarker, CLIP ViT-B/32 (OpenAI weights via open_clip), ResNet18 ImageNet."""
import urllib.request

import _bootstrap  # noqa: F401
from hamstermirror import config


def main():
    config.MODEL_DIR.mkdir(exist_ok=True)
    if not config.MP_FACE_MODEL.exists():
        print(f"downloading {config.MP_FACE_MODEL.name} ...")
        urllib.request.urlretrieve(config.MP_FACE_MODEL_URL, config.MP_FACE_MODEL)
    print("MediaPipe face model ok")
    if not config.MP_HAND_MODEL.exists():
        print(f"downloading {config.MP_HAND_MODEL.name} ...")
        urllib.request.urlretrieve(config.MP_HAND_MODEL_URL, config.MP_HAND_MODEL)
    print("MediaPipe hand model ok")
    if not config.MP_FACE_LANDMARKER.exists():
        print(f"downloading {config.MP_FACE_LANDMARKER.name} ...")
        urllib.request.urlretrieve(config.MP_FACE_LANDMARKER_URL, config.MP_FACE_LANDMARKER)
    print("MediaPipe face landmarker (blendshapes) ok")

    import open_clip

    open_clip.create_model_and_transforms(config.CLIP_MODEL, pretrained=config.CLIP_PRETRAINED)
    print(f"CLIP {config.CLIP_MODEL}/{config.CLIP_PRETRAINED} ok")

    import torchvision

    torchvision.models.resnet18(weights=torchvision.models.ResNet18_Weights.IMAGENET1K_V1)
    print("ResNet18 ImageNet weights ok")


if __name__ == "__main__":
    main()
